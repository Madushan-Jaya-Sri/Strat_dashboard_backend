# Strat_dashboard_backend
Google-Ads, Google-Analytics, Intent insights
